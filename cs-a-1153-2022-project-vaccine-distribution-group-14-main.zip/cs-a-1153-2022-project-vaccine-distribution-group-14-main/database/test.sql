DROP TABLE IF EXISTS Manufacturer;
DROP TABLE IF EXISTS VaccineType;

CREATE TABLE Manufacturer( -- MISSING COUNTRY
    id TEXT,
    country TEXT,
    phone TEXT NOT NULL,
    vaccine TEXT,
    PRIMARY KEY (ID)
);

CREATE TABLE VaccineType( -- OK!
    ID TEXT,
    name TEXT,
    doses INT NOT NULL CHECK (doses >= 1),
    tempMin FLOAT NOT NULL,
    tempMax FLOAT NOT NULL,
    PRIMARY KEY (ID)
);