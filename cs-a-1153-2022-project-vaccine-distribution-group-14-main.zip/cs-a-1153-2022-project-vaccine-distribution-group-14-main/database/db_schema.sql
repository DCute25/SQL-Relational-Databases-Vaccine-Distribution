/*
    Database SQL schema definition for the Vaccination project 
*/


DROP TABLE IF EXISTS Country CASCADE;
DROP TABLE IF EXISTS Manufacturer CASCADE;
DROP TABLE IF EXISTS VaccineType CASCADE;
DROP TABLE IF EXISTS VaccineBatch CASCADE;
DROP TABLE IF EXISTS TransportationLog CASCADE;
DROP TABLE IF EXISTS VaccinationStations CASCADE;
DROP TABLE IF EXISTS StaffMembers CASCADE;
DROP TABLE IF EXISTS Shifts CASCADE;
DROP TABLE IF EXISTS Vaccinations CASCADE;
DROP TABLE IF EXISTS Patients CASCADE;
DROP TABLE IF EXISTS VaccinePatients CASCADE;
DROP TABLE IF EXISTS Symptoms CASCADE;
DROP TABLE IF EXISTS Diagnosis CASCADE;

DROP TABLE IF EXISTS Produce CASCADE;
DROP TABLE IF EXISTS OfficeIn CASCADE;
DROP TABLE IF EXISTS WorkOn CASCADE ;

/*
-----  Main tables -------------------------------------------------------------
*/
--
--CREATE TABLE Country(
--    name TEXT PRIMARY KEY
--);

CREATE TABLE Manufacturer( 
    manuid TEXT PRIMARY KEY,
    phone TEXT NOT NULL,
    vaccine TEXT NOT NULL,
    country TEXT NOT NULL
);

CREATE TABLE VaccineType(
    vaccineid TEXT PRIMARY KEY,
    name TEXT,
    doses INT NOT NULL CHECK (doses >= 1),
    tempMin FLOAT NOT NULL,
    tempMax FLOAT NOT NULL
);

CREATE TABLE VaccinationStations(
    name TEXT PRIMARY KEY,
    address TEXT NOT NULL,
    phone TEXT NOT NULL
);

CREATE TABLE VaccineBatch(
    batchID TEXT PRIMARY KEY,
    amount INT NOT NULL CHECK (amount >= 0),
    type TEXT REFERENCES VaccineType(vaccineid),
    manufacturer TEXT REFERENCES Manufacturer(manuid),
    manufDate DATE NOT NULL,
    expiration DATE NOT NULL,
    location TEXT REFERENCES VaccinationStations(name)
);

CREATE TABLE TransportationLog(
    logID SERIAL PRIMARY KEY, -- incrementing index
    batchID TEXT REFERENCES VaccineBatch(batchID),
    arrival TEXT REFERENCES VaccinationStations(name),
    departure TEXT REFERENCES VaccinationStations(name),
    dateArr DATE NOT NULL,
    dateDep DATE NOT NULL
);

CREATE TABLE StaffMembers(
    ssno TEXT NOT NULL PRIMARY KEY,
    name TEXT NOT NULL,
    birthday DATE NOT NULL,
    phone TEXT NOT NULL,
    role TEXT CHECK(role in ('nurse','doctor')),
    vaccineStatus INT NOT NULL,
    station TEXT REFERENCES VaccinationStations(name)
);

CREATE TABLE Shifts(
    shiftID INT PRIMARY KEY,
    station TEXT REFERENCES VaccinationStations(name), 
    weekday TEXT NOT NULL
    --- worker TEXT REFERENCES StaffMembers(ssno)
);

CREATE TABLE Vaccinations(
    date DATE,
    station TEXT REFERENCES VaccinationStations(name),
    batchID TEXT REFERENCES VaccineBatch(batchID),
    shiftID INT REFERENCES Shifts(shiftID),
    PRIMARY KEY (date, station)
);
     
CREATE TABLE Patients(
    ssNo TEXT PRIMARY KEY,
    name TEXT NOT NULL, 
    birthday DATE NOT NULL,
    gender TEXT NOT NULL
);

CREATE TABLE VaccinePatients(
    date DATE,
    location TEXT REFERENCES VaccinationStations(name),
    patient TEXT REFERENCES Patients(ssno),

    PRIMARY KEY (date, patient)
);

CREATE TABLE Symptoms(
    name TEXT PRIMARY KEY,
    criticality INT NOT NULL
);

CREATE TABLE Diagnosis(
    patient TEXT REFERENCES Patients(ssno),
    symptom TEXT REFERENCES Symptoms(name),
    date DATE,
    
    PRIMARY KEY (date, symptom, patient)
);

/*
----- Associations -------------------------------------------------------------
*/



CREATE TABLE WorkOn(
    staff TEXT REFERENCES StaffMembers(ssno),
    shiftID INT REFERENCES Shifts(shiftID)
);

/*
--------------------------------------------------------------------------------
*/